# 2025-06-17T14:34:53.800271200
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_code")

vitis.dispose()

