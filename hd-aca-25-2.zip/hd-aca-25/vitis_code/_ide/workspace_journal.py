# 2025-06-17T19:02:45.325831500
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_code")

comp = client.get_component(name="hello_world")
status = comp.clean()

platform = client.get_component(name="platform")
status = platform.build()

comp.build()

status = comp.clean()

status = platform.build()

comp.build()

vitis.dispose()

