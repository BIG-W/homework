# 2025-06-16T19:06:45.892240700
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_code")

vitis.dispose()

