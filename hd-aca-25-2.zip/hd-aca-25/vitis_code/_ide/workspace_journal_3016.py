# 2025-06-15T15:30:42.964319600
import vitis

client = vitis.create_client()
client.set_workspace(path="vitis_code")

vitis.dispose()

