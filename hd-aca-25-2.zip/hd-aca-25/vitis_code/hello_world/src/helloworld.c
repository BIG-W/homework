/******************************************************************************
* Copyright (C) 2023 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/
/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
//#include <sys/_intsup.h>
#include <xil_io.h>
#include <sleep.h>
//#include <mb_interface.h>
#include <xil_exception.h>
#include <xil_types.h>

#define GPIO_BASE_ADDR  0x40000000
#define GPIO_DATA_REG   (GPIO_BASE_ADDR + 0x0)
#define GPIO_DIR_REG    (GPIO_BASE_ADDR + 0x4)

#define TIMER_BASE_ADDR 0x41C00000
#define TIMER0_SET_REG   (TIMER_BASE_ADDR + 0x0)
#define TIMER1_SET_REG   (TIMER_BASE_ADDR + 0x10)
#define TIMER0_DATA_RW_REG  (TIMER_BASE_ADDR + 0x4)
#define TIMER1_DATA_RW_REG  (TIMER_BASE_ADDR + 0x14)
#define TIMER0_DATA_RO_REG  (TIMER_BASE_ADDR + 0x8)
#define TIMER1_DATA_RO_REG  (TIMER_BASE_ADDR + 0x18)

#define TCSR_MDT   (1 << 0)  
#define TCSR_UDT   (1 << 1)   
#define TCSR_GENT  (1 << 2)   
#define TCSR_CAPT  (1 << 3)  
#define TCSR_ARHT  (1 << 4)   
#define TCSR_LOAD  (1 << 5)   
#define TCSR_ENIT  (1 << 6)   
#define TCSR_ENT   (1 << 7)   
#define TCSR_TINT  (1 << 8)  
#define TCSR_PWM   (1 << 9)   
#define TCSR_ENALL (1 << 10)

#define PWM0_BIT    9
#define PWM0_FREQUENCY  10
#define PWM0_RESOLUTION 100

#define LD5_RED_BIT    16
#define LD5_GREEN_BIT  17
#define LD5_BLUE_BIT   18
#define BUTTON_SWITCH_BIT   0

#define SYS_CLK_FREQ    125000000
#define TIMER_TICK_PER_MS   (SYS_CLK_FREQ / 1000)
#define TIMER_RESET_VALUE  (SYS_CLK_FREQ / (PWM0_RESOLUTION * PWM0_FREQUENCY))

static int button_press_num = 0;
volatile int pwm_update_flag = 0;
volatile int pwm_duty_next = 0;

void hd_gpio_set_output(_Bool set_value)
{
    u32 data_val = Xil_In32(GPIO_DATA_REG);

    data_val &= ~((1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
    
    if (set_value) {
        data_val |= (1 << LD5_RED_BIT);   
    } else {
        data_val &= ~(1 << LD5_RED_BIT);  
    }
    Xil_Out32(GPIO_DATA_REG, data_val);    
}

void hd_timer_pwm(u32 time)
{
    Xil_Out32(TIMER0_DATA_RW_REG, 0x0);
    Xil_Out32(TIMER0_SET_REG, ((TCSR_LOAD | TCSR_ENT) & (~TCSR_UDT)));
    while ((Xil_In32(TIMER0_DATA_RO_REG)) < time) {
        asm("nop");
        break;        
    }
}

void hd_pwm_duty_output(unsigned int duty_value)
{
    u32 high_time = (TIMER_TICK_PER_MS * duty_value) / PWM0_RESOLUTION;
    u32 low_time = ((PWM0_RESOLUTION * TIMER_TICK_PER_MS) - high_time);

    if (high_time == 0) {
        hd_gpio_set_output(FALSE);
        hd_timer_pwm(low_time);
    } else {
        hd_gpio_set_output(TRUE);
        hd_timer_pwm(high_time);
    
        hd_gpio_set_output(FALSE);
        hd_timer_pwm(low_time);
    }

}

void hd_gpio_init()
{
    //set the LD5 to light the red color
    u32 dir_val = Xil_In32(GPIO_DIR_REG);
    dir_val &= ~((1 << LD5_RED_BIT) | (1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
    Xil_Out32(GPIO_DIR_REG, dir_val);

    u32 data_val = Xil_In32(GPIO_DATA_REG);
    data_val &= ~(1 << LD5_RED_BIT);
    data_val &= ~((1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
    Xil_Out32(GPIO_DATA_REG, data_val);    

    //set the button 0
    u32 dir_val_bs = Xil_In32(GPIO_DIR_REG);
    dir_val_bs |= (1 << BUTTON_SWITCH_BIT);
    Xil_Out32(GPIO_DIR_REG, dir_val_bs);
}

void hd_timer_pwm_init()
{
    //set the pwm of the timer0
    u32 pwm0_enable_val = Xil_In32(TIMER0_SET_REG);
    pwm0_enable_val |= (1 << PWM0_BIT);
    Xil_Out32(TIMER0_SET_REG, pwm0_enable_val);    
}

void TimerInterruptHandler(void *Data, u8 Timernum)
{
    (void)Data;
    (void)Timernum;
    Xil_Out32(TIMER1_SET_REG, Xil_In32(TIMER1_SET_REG) | TCSR_TINT);

    switch (button_press_num) {
        case 0:
                pwm_duty_next = 0;
                print("interrupt0\n\r");
                break;
            case 1:
                pwm_duty_next = 25;
                print("interrupt1\n\r");
                break;
            case 2:
                pwm_duty_next = 50;
                print("interrupt2\n\r");
                break;
            case 3:
                pwm_duty_next = 75;
                print("interrupt3\n\r");
                break;
            case 4:
                pwm_duty_next = 100;
                print("interrupt4\n\r");
                break;
            default:
                print("interrupt5\n\r");
                break;
    }
    pwm_update_flag = 1;
}

void hd_timer_interinit()
{
    Xil_Out32(TIMER1_DATA_RW_REG, 0x5F5E100);
    Xil_Out32(TIMER1_SET_REG, TCSR_LOAD);
    Xil_Out32(TIMER1_SET_REG, TCSR_ARHT | TCSR_ENIT | TCSR_ENT);
    Xil_ExceptionInit();
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT, (Xil_ExceptionHandler)TimerInterruptHandler, NULL);
    Xil_ExceptionEnable();
}

int main()
{
    init_platform();
    static int last = 0;
    static int ready = 1;

    print("Hello World\n\r");
    hd_gpio_init();
    hd_timer_pwm_init();
    hd_timer_interinit();
    
    while (1) {
        int cur = (Xil_In32(GPIO_DATA_REG) & (1 << BUTTON_SWITCH_BIT)) ? 1 : 0;

        if (cur == 0) {
            ready = 1;
        }

        if (cur == 1 && last == 0 && ready) {
            msleep(10);
            if (Xil_In32(GPIO_DATA_REG) & (1 << BUTTON_SWITCH_BIT)) {
                button_press_num++;
                if (button_press_num > 4) {
                    button_press_num = 0;
                }
            print("Button pressed and released, num = \n\r");
            ready = 0;
            }
        }
        last = cur;
        if (pwm_update_flag) {
            hd_pwm_duty_output(pwm_duty_next);
            pwm_update_flag = 0;
        }           
    }   
    print("Successfully ran Hello World application");
    cleanup_platform();
    return 0;
}
