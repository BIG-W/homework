/******************************************************************************
* Copyright (C) 2023 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/
/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdint.h>
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include <sys/_intsup.h>
#include <xil_io.h>
#include <sleep.h>
#include <xil_types.h>

#define GPIO_BASE_ADDR  0x40000000
#define GPIO_DATA_REG   (GPIO_BASE_ADDR + 0x0)
#define GPIO_DIR_REG    (GPIO_BASE_ADDR + 0x4)

#define TIMER_BASE_ADDR 0x41C00000
#define TIMER0_SET_REG   (TIMER_BASE_ADDR + 0x0)
#define TIMER0_DATA_RW_REG  (TIMER_BASE_ADDR + 0x4)
#define TIMER0_DATA_RO_REG  (TIMER_BASE_ADDR + 0x8)

#define PWM0_BIT    9
#define PWM0_FREQUENCY  10
#define PWM0_RESOLUTION 100

#define LD5_RED_BIT    16
#define LD5_GREEN_BIT  17
#define LD5_BLUE_BIT   18
#define BUTTON_SWITCH_BIT   0

#define SYS_CLK_FREQ    125000000
#define TIMER_TICK_PER_MS   (SYS_CLK_FREQ / 1000)

void gpio_set_output(_Bool set_value)
{
    if (set_value == TRUE) {
        u32 data_val = Xil_In32(GPIO_DATA_REG);
        data_val |= (1 << LD5_RED_BIT);
        data_val &= ~((1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
        Xil_Out32(GPIO_DATA_REG, data_val);
    } else {
        u32 data_val = Xil_In32(GPIO_DATA_REG);
        data_val &= ~(1 << LD5_RED_BIT);
        data_val &= ~((1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
        Xil_Out32(GPIO_DATA_REG, data_val);
    }
}

void timer_pwm(u32 time)
{
    Xil_Out32(TIMER0_DATA_RW_REG, 0x0);
    while ((Xil_In32(TIMER0_DATA_RO_REG)) < time) {
        asm("nop");
        break;        
    }
}

void pwm_duty_output(unsigned int duty_value)
{
    u32 high_time = (TIMER_TICK_PER_MS * duty_value);
    u32 low_time = ((PWM0_RESOLUTION * TIMER_TICK_PER_MS) - high_time);

    if (high_time == 0)
    {
        gpio_set_output(0);
        timer_pwm(low_time);
    } else {
        gpio_set_output(1);
        timer_pwm(high_time);
    
        gpio_set_output(0);
        timer_pwm(low_time);
    }
}

void gpio_init()
{
    //set the LD5 to light the red color
    u32 dir_val = Xil_In32(GPIO_DIR_REG);
    dir_val &= ~((1 << LD5_RED_BIT) | (1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
    Xil_Out32(GPIO_DIR_REG, dir_val);

    u32 data_val = Xil_In32(GPIO_DATA_REG);
    data_val &= ~(1 << LD5_RED_BIT);
    data_val &= ~((1 << LD5_GREEN_BIT) | (1 << LD5_BLUE_BIT));
    Xil_Out32(GPIO_DATA_REG, data_val);    

    //set the button 0
    u32 dir_val_bs = Xil_In32(GPIO_DIR_REG);
    dir_val_bs |= (1 << BUTTON_SWITCH_BIT);
    Xil_Out32(GPIO_DIR_REG, dir_val_bs);
}
void timer_pwm_init()
{
    //set the pwm of the timer0
    u32 pwm0_enable_val = Xil_In32(TIMER0_SET_REG);
    pwm0_enable_val |= (1 << PWM0_BIT);
    Xil_Out32(TIMER0_SET_REG, pwm0_enable_val);    
}
int main()
{
    init_platform();
    static int button_press_num = 0;
    uint32_t button_press = 0;
    uint32_t last_button_status = 0;

    print("Hello World\n\r");
    gpio_init();
    timer_pwm_init();

    while (1) {
        u32 button_status = Xil_In32(GPIO_DATA_REG) & (1 << BUTTON_SWITCH_BIT);
        
        if (last_button_status && !button_press) {
            msleep(10);
            u32 button_status = Xil_In32(GPIO_DATA_REG) & (1 << BUTTON_SWITCH_BIT);

            if (!button_status)
            {
                button_press = 1;
            }
        }
        if (button_press)
        {
            button_press = 0;
            button_press_num += 1;          
        }
        switch (button_press_num) {
            case 0:
                pwm_duty_output(0);
                break;
            case 1:
                pwm_duty_output(25);
                break;
            case 2:
                pwm_duty_output(50);
                break;
            case 3:
                pwm_duty_output(75);
                break;
            case 4:
                pwm_duty_output(100);
                break;
            default:
                break;
        }
        if (button_press_num >= 5) {
            button_press_num = 0;
        }
        last_button_status = button_status;
    }

    print("Successfully ran Hello World application");
    cleanup_platform();
    return 0;
}
