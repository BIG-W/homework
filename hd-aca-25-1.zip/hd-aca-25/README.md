# Advanced Computer Architecture Course 2025 

Instructions for getting started with a vivado project. 

```sh
git clone https://www.github.com/lukevassallo/hd-aca-25
cd hd-aca-25

# Enter the container
bash start.sh
```
From within the container, you can start vivado by typing the `vivado` command, and vitis with the `vitis --classic` command. 
 
