singularity shell /shares/ziti-opt/software/cat/aca2025.sif

